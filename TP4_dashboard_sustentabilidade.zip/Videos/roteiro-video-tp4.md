# Roteiro do vídeo - TP4

Olá, meu nome é Caio Augusto C. G. e este é o vídeo de apresentação do TP4 do projeto Dashboard de Sustentabilidade, relacionado ao ODS 13.

Nesta sprint, o entregável iniciado no TP3 foi evoluído. Agora, a aplicação possui uma tela de login simples, filtro por país, filtro por ano, gráfico de emissão de CO₂, tabela com os dados e exportação em CSV.

No backend, foi mantida a API em Node.js com Express. Foram adicionadas rotas para login, consulta de dados de CO₂, listagem de países e listagem de anos disponíveis.

No frontend, desenvolvido em React, foi adicionada a tela de login e a interface do dashboard foi atualizada para permitir filtros combinados por país e ano.

Também foi criada uma página de plano de testes na pasta docs, contendo pelo menos três casos de teste para cada caso de uso principal da aplicação.

Por fim, o GitHub Projects deve ser atualizado com as atividades concluídas no TP4 e com o planejamento das tarefas da sprint TP5.

## O que mostrar no vídeo

1. Mostrar o repositório no GitHub.
2. Mostrar as pastas `backend`, `frontend`, `docs` e `Videos`.
3. Mostrar o arquivo `docs/plano-de-testes.md`.
4. Executar o backend.
5. Executar o frontend.
6. Fazer login com usuário de teste.
7. Mostrar o dashboard.
8. Filtrar por país.
9. Filtrar por ano.
10. Exportar CSV.
11. Mostrar o planejamento do TP5.

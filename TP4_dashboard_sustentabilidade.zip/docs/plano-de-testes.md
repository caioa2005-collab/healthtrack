# Plano de Testes da Aplicação

**Projeto:** Dashboard de Sustentabilidade  
**Aluno:** Caio Augusto C. G.  
**Sprint:** TP4

## 1. Objetivo

Este plano de testes tem como objetivo descrever casos de teste para validar as principais funcionalidades do Dashboard de Sustentabilidade, considerando os casos de uso definidos no projeto.

## 2. Casos de uso considerados

1. Realizar login;
2. Visualizar gráficos de emissão de CO₂;
3. Filtrar dados por país;
4. Filtrar dados por ano;
5. Exportar dados em CSV.

---

## 3. Caso de uso: Realizar login

### CT01 - Login com dados válidos

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o sistema permite acesso com e-mail e senha válidos. |
| Pré-condição | Backend e frontend em execução. |
| Entrada | E-mail: aluno@teste.com; Senha: 123456. |
| Resultado esperado | O usuário deve ser direcionado ao dashboard. |

### CT02 - Login com senha inválida

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o sistema bloqueia acesso com senha incorreta. |
| Entrada | E-mail válido e senha incorreta. |
| Resultado esperado | O sistema deve exibir mensagem de erro. |

### CT03 - Login com campos vazios

| Item | Descrição |
|---|---|
| Objetivo | Verificar o comportamento do sistema ao tentar entrar sem preencher os campos. |
| Entrada | E-mail vazio e senha vazia. |
| Resultado esperado | O sistema não deve permitir o acesso. |

---

## 4. Caso de uso: Visualizar gráficos de emissão de CO₂

### CT04 - Exibição inicial do gráfico

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o gráfico é exibido após o login. |
| Pré-condição | Usuário autenticado. |
| Resultado esperado | O gráfico deve ser apresentado na tela com os dados disponíveis. |

### CT05 - Gráfico com dados de todos os países

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o gráfico exibe dados quando nenhum filtro é selecionado. |
| Resultado esperado | O gráfico deve apresentar os dados gerais disponíveis. |

### CT06 - Gráfico após atualização de filtro

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o gráfico é atualizado após aplicação de filtro. |
| Resultado esperado | O gráfico deve refletir os dados filtrados. |

---

## 5. Caso de uso: Filtrar dados por país

### CT07 - Filtrar por Brasil

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o sistema retorna apenas dados do Brasil. |
| Entrada | País: Brasil. |
| Resultado esperado | A tabela e o gráfico devem apresentar apenas registros do Brasil. |

### CT08 - Filtrar por China

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o filtro por país funciona para China. |
| Entrada | País: China. |
| Resultado esperado | A tabela e o gráfico devem apresentar apenas registros da China. |

### CT09 - Limpar filtro por país

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o sistema volta a exibir todos os países após limpar filtros. |
| Resultado esperado | Todos os dados devem ser exibidos novamente. |

---

## 6. Caso de uso: Filtrar dados por ano

### CT10 - Filtrar por ano específico

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o sistema retorna apenas dados do ano selecionado. |
| Entrada | Ano: 2022. |
| Resultado esperado | A tabela e o gráfico devem apresentar apenas registros de 2022. |

### CT11 - Combinar filtro de país e ano

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o sistema filtra simultaneamente por país e ano. |
| Entrada | País: Brasil; Ano: 2022. |
| Resultado esperado | Deve ser exibido apenas o registro do Brasil em 2022. |

### CT12 - Limpar filtro por ano

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o sistema volta a exibir dados de todos os anos. |
| Resultado esperado | Todos os anos disponíveis devem voltar a aparecer. |

---

## 7. Caso de uso: Exportar dados em CSV

### CT13 - Exportar todos os dados

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o sistema exporta os dados gerais em CSV. |
| Resultado esperado | Um arquivo CSV deve ser baixado com os dados exibidos. |

### CT14 - Exportar dados filtrados por país

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o CSV exportado respeita o filtro aplicado. |
| Entrada | País: Brasil. |
| Resultado esperado | O CSV deve conter apenas dados do Brasil. |

### CT15 - Exportar dados filtrados por país e ano

| Item | Descrição |
|---|---|
| Objetivo | Verificar se o CSV exportado respeita filtros combinados. |
| Entrada | País: Brasil; Ano: 2022. |
| Resultado esperado | O CSV deve conter apenas o registro filtrado. |

---

## 8. Conclusão

O plano de testes cobre os principais casos de uso da aplicação e permite validar o funcionamento básico do sistema. Em etapas futuras, esses testes poderão ser automatizados com ferramentas de teste end-to-end, como Cypress.

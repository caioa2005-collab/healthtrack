# TP4 - Sprint de Desenvolvimento + Plano de Testes

**Aluno:** Caio Augusto C. G.  
**Projeto:** Dashboard de Sustentabilidade  
**ODS escolhido:** ODS 13 – Ação contra a mudança global do clima

## 1. Objetivo da sprint

O objetivo do TP4 foi evoluir o entregável funcional iniciado no TP3 e criar uma página de plano de testes da aplicação. Nesta sprint, foram adicionadas novas funcionalidades, como login simples e filtro por ano, além da organização do planejamento para o TP5.

## 2. Evoluções realizadas

- Implementação de login simples com usuário de teste;
- Inclusão do filtro por ano;
- Melhoria da API com rota de anos disponíveis;
- Atualização do dashboard com mais dados;
- Manutenção do filtro por país;
- Manutenção da exportação CSV;
- Criação da página de plano de testes;
- Criação do planejamento do TP5;
- Atualização do roteiro de vídeo.

## 3. Estado atual da solução

A aplicação possui uma tela de login inicial. Após autenticação, o usuário acessa o dashboard e pode visualizar dados de emissão de CO₂, filtrar por país e ano, consultar os dados em tabela e exportar as informações em CSV.

## 4. Funcionalidades implementadas até o TP4

| Código | Funcionalidade | Status |
|---|---|---|
| RF01 | Login de usuário | Implementado de forma simples |
| RF02 | Visualização de gráficos de CO₂ | Implementado |
| RF03 | Filtro por país | Implementado |
| RF04 | Filtro por ano | Implementado |
| RF05 | Exportação CSV | Implementado |
| RF06 | Consulta de dados ambientais | Implementado com dados simulados |
| RF07 | Interface responsiva | Parcialmente implementado |

## 5. Limitações atuais

- O login ainda é simplificado e não utiliza banco de dados;
- Os dados ambientais ainda são simulados;
- A integração com API externa real será tratada em sprint posterior;
- Os testes estão documentados, mas ainda não foram automatizados.

## 6. Conclusão

O TP4 evoluiu o protótipo funcional do TP3, adicionando autenticação simples, filtro por ano e uma documentação formal de plano de testes. A solução está preparada para o TP5, no qual poderão ser implementadas melhorias de autenticação, integração com dados reais e testes automatizados.

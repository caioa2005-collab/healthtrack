# Planejamento do TP5

**Projeto:** Dashboard de Sustentabilidade  
**Aluno:** Caio Augusto C. G.

## Done

- Estrutura inicial do frontend;
- Estrutura inicial do backend;
- API REST com dados simulados;
- Gráfico de emissão de CO₂;
- Filtro por país;
- Filtro por ano;
- Login simples;
- Exportação CSV;
- Plano de testes;
- Documentação TP4.

## TODO - Sprint TP5

- Implementar autenticação com armazenamento de usuários;
- Integrar API externa real de dados climáticos;
- Criar testes end-to-end com Cypress;
- Melhorar responsividade mobile;
- Criar gráfico comparativo entre países;
- Melhorar tratamento de erros;
- Criar tela de detalhes por país;
- Atualizar vídeo final da solução.

## In Progress

- Nenhuma atividade no momento.

## Project Backlog

- Cadastro de usuário;
- Histórico de consultas;
- Exportação de relatórios em PDF;
- Dashboard com indicadores resumidos;
- Deploy da aplicação.

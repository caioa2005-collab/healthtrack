import { useEffect, useState } from "react";
import Login from "./components/Login";
import Co2Chart from "./components/Co2Chart";
import { buscarDadosCo2, buscarPaises, buscarAnos } from "./services/api";
function App() {
  const [usuario, setUsuario] = useState(null), [dados, setDados] = useState([]), [paises, setPaises] = useState([]), [anos, setAnos] = useState([]);
  const [paisSelecionado, setPaisSelecionado] = useState(""), [anoSelecionado, setAnoSelecionado] = useState(""), [erro, setErro] = useState("");
  async function carregarDados(pais = paisSelecionado, ano = anoSelecionado) { try { setErro(""); setDados(await buscarDadosCo2(pais, ano)); } catch { setErro("Não foi possível carregar os dados. Verifique se o backend está rodando."); } }
  async function carregarFiltros() { try { setPaises(await buscarPaises()); setAnos(await buscarAnos()); } catch { setErro("Não foi possível carregar os filtros."); } }
  useEffect(() => { if (usuario) { carregarFiltros(); carregarDados("", ""); } }, [usuario]);
  function alterarPais(e) { const pais=e.target.value; setPaisSelecionado(pais); carregarDados(pais, anoSelecionado); }
  function alterarAno(e) { const ano=e.target.value; setAnoSelecionado(ano); carregarDados(paisSelecionado, ano); }
  function limparFiltros() { setPaisSelecionado(""); setAnoSelecionado(""); carregarDados("", ""); }
  function exportarCSV() { if (!dados.length) return; const conteudo = "pais,ano,emissao\n" + dados.map(i => `${i.pais},${i.ano},${i.emissao}`).join("\n"); const arquivo = new Blob([conteudo], { type: "text/csv;charset=utf-8;" }); const url = URL.createObjectURL(arquivo); const link = document.createElement("a"); link.href = url; link.download = "dados_emissao_co2.csv"; link.click(); URL.revokeObjectURL(url); }
  if (!usuario) return <Login onLogin={setUsuario} />;
  return <main className="container"><header className="header"><div className="top-line"><span className="badge">ODS 13</span><button className="secondary" onClick={() => setUsuario(null)}>Sair</button></div><h1>Dashboard de Sustentabilidade</h1><p>Visualização de dados de emissão de CO₂ por país, com filtros, gráfico, tabela e exportação CSV.</p><small>Usuário logado: {usuario.nome}</small></header><section className="controls"><label htmlFor="pais">País:</label><select id="pais" value={paisSelecionado} onChange={alterarPais}><option value="">Todos os países</option>{paises.map(pais => <option key={pais} value={pais}>{pais}</option>)}</select><label htmlFor="ano">Ano:</label><select id="ano" value={anoSelecionado} onChange={alterarAno}><option value="">Todos os anos</option>{anos.map(ano => <option key={ano} value={ano}>{ano}</option>)}</select><button onClick={limparFiltros}>Limpar filtros</button><button onClick={exportarCSV}>Exportar CSV</button></section>{erro && <p className="error">{erro}</p>}<Co2Chart dados={dados} /><section className="table-card"><h2>Dados exibidos</h2><table><thead><tr><th>País</th><th>Ano</th><th>Emissão de CO₂</th></tr></thead><tbody>{dados.map((item,index)=><tr key={`${item.pais}-${item.ano}-${index}`}><td>{item.pais}</td><td>{item.ano}</td><td>{item.emissao}</td></tr>)}</tbody></table></section></main>;
}
export default App;

# Projeto ODS: Dashboard de Sustentabilidade

**Aluno:** Caio Augusto C. G.  
**ODS escolhido:** ODS 13 – Ação contra a mudança global do clima

## Entrega TP4

Nesta sprint, o entregável iniciado no TP3 foi evoluído e foi criado o plano de testes da aplicação.

### Funcionalidades atuais

- Backend em Node.js + Express;
- Frontend em React + Vite;
- API REST com dados de emissão de CO₂;
- Login simples de usuário;
- Filtro por país;
- Filtro por ano;
- Gráfico de emissão de CO₂;
- Tabela de dados;
- Exportação CSV;
- Plano de testes;
- Planejamento TP5;
- Roteiro do vídeo na pasta `Videos`.

## Como executar o backend

```bash
cd backend
npm install
npm start
```

Backend: `http://localhost:3001`

## Como executar o frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend: `http://localhost:5173`

## Usuário de teste

- E-mail: `aluno@teste.com`
- Senha: `123456`

## Documentação

- `docs/tp4-sprint-desenvolvimento.md`
- `docs/plano-de-testes.md`
- `docs/planejamento-tp5.md`
